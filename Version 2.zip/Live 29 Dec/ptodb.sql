-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2022 at 01:57 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ptodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `month`
--

CREATE TABLE `month` (
  `id` int(11) NOT NULL,
  `date` text NOT NULL,
  `pto` int(11) NOT NULL,
  `public` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `month`
--

INSERT INTO `month` (`id`, `date`, `pto`, `public`) VALUES
(5, '1/2/2023', 15, 16),
(11, '1/5/2023', 5, 7),
(12, '1/13/2023', 7, 7),
(13, '1/10/2023', 6, 8),
(16, '1/6/2023', 16, 15),
(17, '1/26/2023', 16, 10),
(18, '1/27/2023', 15, 16),
(19, '1/30/2023', 14, 16),
(20, '1/31/2023', 15, 16),
(21, '1/1/2023', 15, 16),
(22, '1/3/2023', 15, 16),
(23, '1/4/2023', 15, 16),
(24, '1/11/2023', 15, 16),
(25, '1/19/2023', 15, 16),
(26, '1/20/2023', 15, 16),
(27, '1/21/2023', 15, 16),
(28, '1/16/2023', 15, 16),
(29, '1/8/2023', 16, 14),
(30, '1/18/2023', 15, 16);

-- --------------------------------------------------------

--
-- Table structure for table `pto_record`
--

CREATE TABLE `pto_record` (
  `id` int(5) NOT NULL,
  `ownerID` int(5) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `ownerName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ptolist` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pto_record`
--

INSERT INTO `pto_record` (`id`, `ownerID`, `timestamp`, `ownerName`, `ptolist`) VALUES
(249, 55, '2022-12-27 14:00:35', 'Zeinab El Sayed', '[{\"date\": \"1/28/2023\", \"title\": \"Saturday\", \"requester\": \"Zeinab El Sayed\"}]'),
(251, 42, '2022-12-27 14:08:13', 'Nourhan Soliman', '[{\"date\": \"1/21/2023\", \"title\": \"Saturday\", \"requester\": \"Nourhan Soliman\"}]'),
(254, 7, '2022-12-27 14:13:07', 'ahmed seif', '[{\"date\": \"1/7/2023\", \"title\": \"Saturday\", \"requester\": \"ahmed seif\"}]'),
(255, 15, '2022-12-27 14:14:50', 'Dawlat Elgendy', '[{\"date\": \"1/14/2023\", \"title\": \"Saturday\", \"requester\": \"Dawlat Elgendy\"}]'),
(259, 29, '2022-12-27 14:18:21', 'Michael Masry', '[{\"date\": \"1/6/2023\", \"title\": \"PTO\", \"requester\": \"Michael Masry\"}]'),
(260, 42, '2022-12-27 14:50:05', 'Nourhan Soliman', '[{\"date\": \"1/26/2023\", \"title\": \"Public\", \"requester\": \"Nourhan Soliman\"}]'),
(261, 33, '2022-12-27 14:53:00', 'Mohamed Krima', '[]'),
(262, 53, '2022-12-27 15:02:10', 'Yousef Shaltout', '[{\"date\": \"1/28/2023\", \"title\": \"Saturday\", \"requester\": \"Yousef Shaltout\"}]'),
(263, 51, '2022-12-27 15:29:59', 'Samer Elhosainy', '[{\"date\": \"1/27/2023\", \"title\": \"PTO\", \"requester\": \"Samer Elhosainy\"}]'),
(264, 51, '2022-12-27 15:33:37', 'Samer Elhosainy', '[{\"date\": \"1/30/2023\", \"title\": \"PTO\", \"requester\": \"Samer Elhosainy\"}]'),
(265, 48, '2022-12-27 22:35:05', 'reem hesham ', '[{\"date\": \"1/30/2023\", \"title\": \"PTO\", \"requester\": \"reem hesham \"}, {\"date\": \"1/31/2023\", \"title\": \"PTO\", \"requester\": \"reem hesham \"}]'),
(266, 44, '2022-12-28 07:24:53', 'Radwa Khairy', '[{\"date\": \"1/26/2023\", \"title\": \"Public\", \"requester\": \"Radwa Khairy\"}]'),
(269, 21, '2022-12-28 11:15:34', 'Kareem Ramadan', '[]'),
(270, 28, '2022-12-28 11:16:11', 'Mennatallah Sayed', '[{\"date\": \"1/14/2023\", \"title\": \"Saturday\", \"requester\": \"Mennatallah Sayed\"}]'),
(271, 10, '2022-12-28 11:27:19', 'Ali Rashwan', '[{\"date\": \"1/26/2023\", \"title\": \"Public\", \"requester\": \"Ali Rashwan\"}]'),
(272, 52, '2022-12-28 11:27:23', 'Sohayla Fath Elbab', '[{\"date\": \"1/14/2023\", \"title\": \"Saturday\", \"requester\": \"Sohayla Fath Elbab\"}]'),
(274, 16, '2022-12-28 11:31:31', 'Faisal Essam', '[{\"date\": \"1/7/2023\", \"title\": \"Saturday\", \"requester\": \"Faisal Essam\"}]'),
(275, 52, '2022-12-28 12:29:19', 'Sohayla Fath Elbab', '[{\"date\": \"1/26/2023\", \"title\": \"Public\", \"requester\": \"Sohayla Fath Elbab\"}]'),
(277, 24, '2022-12-28 13:39:25', 'Mahmoud Osama', '[{\"date\": \"1/1/2023\", \"title\": \"PTO\", \"requester\": \"Mahmoud Osama\"}, {\"date\": \"1/2/2023\", \"title\": \"PTO\", \"requester\": \"Mahmoud Osama\"}, {\"date\": \"1/3/2023\", \"title\": \"PTO\", \"requester\": \"Mahmoud Osama\"}, {\"date\": \"1/4/2023\", \"title\": \"PTO\", \"requester\": \"Mahmoud Osama\"}, {\"date\": \"1/5/2023\", \"title\": \"PTO\", \"requester\": \"Mahmoud Osama\"}]'),
(278, 24, '2022-12-28 13:49:06', 'Mahmoud Osama', '[{\"date\": \"1/21/2023\", \"title\": \"Saturday\", \"requester\": \"Mahmoud Osama\"}]'),
(279, 34, '2022-12-28 14:04:03', 'MohamedLoaui Zamzam', '[{\"date\": \"1/21/2023\", \"title\": \"Saturday\", \"requester\": \"MohamedLoaui Zamzam\"}]'),
(280, 47, '2022-12-28 14:05:05', 'Reem Gendy', '[{\"date\": \"1/21/2023\", \"title\": \"Saturday\", \"requester\": \"Reem Gendy\"}]'),
(281, 21, '2022-12-28 14:06:24', 'Kareem Ramadan', '[{\"date\": \"1/21/2023\", \"title\": \"Saturday\", \"requester\": \"Kareem Ramadan\"}]'),
(282, 4, '2022-12-28 14:34:12', 'Abdelrahman Khaled', '[{\"date\": \"1/14/2023\", \"title\": \"Saturday\", \"requester\": \"Abdelrahman Khaled\"}]'),
(283, 3, '2022-12-28 14:50:20', 'Abdelrahman Hesham', '[{\"date\": \"1/7/2023\", \"title\": \"Saturday\", \"requester\": \"Abdelrahman Hesham\"}]'),
(284, 44, '2022-12-28 17:11:30', 'Radwa Khairy', '[{\"date\": \"1/10/2023\", \"title\": \"PTO\", \"requester\": \"Radwa Khairy\"}, {\"date\": \"1/11/2023\", \"title\": \"PTO\", \"requester\": \"Radwa Khairy\"}]'),
(285, 44, '2022-12-28 17:14:26', 'Radwa Khairy', '[{\"date\": \"1/13/2023\", \"title\": \"PTO\", \"requester\": \"Radwa Khairy\"}, {\"date\": \"1/19/2023\", \"title\": \"PTO\", \"requester\": \"Radwa Khairy\"}, {\"date\": \"1/20/2023\", \"title\": \"PTO\", \"requester\": \"Radwa Khairy\"}]'),
(286, 44, '2022-12-28 17:22:56', 'Radwa Khairy', '[{\"date\": \"1/21/2023\", \"title\": \"PTO\", \"requester\": \"Radwa Khairy\"}, {\"date\": \"1/16/2023\", \"title\": \"PTO\", \"requester\": \"Radwa Khairy\"}]'),
(287, 39, '2022-12-29 08:53:22', 'Nada Wafa', '[{\"date\": \"1/8/2023\", \"title\": \"Public\", \"requester\": \"Nada Wafa\"}, {\"date\": \"1/5/2023\", \"title\": \"PTO\", \"requester\": \"Nada Wafa\"}, {\"date\": \"1/26/2023\", \"title\": \"Public\", \"requester\": \"Nada Wafa\"}, {\"date\": \"1/21/2023\", \"title\": \"Other\", \"requester\": \"Nada Wafa\"}, {\"date\": \"1/25/2023\", \"title\": \"Other\", \"requester\": \"Nada Wafa\"}]'),
(288, 29, '2022-12-29 09:37:02', 'Michael Masry', '[{\"date\": \"1/18/2023\", \"title\": \"PTO\", \"requester\": \"Michael Masry\"}]'),
(289, 39, '2022-12-29 09:47:26', 'Nada Wafa', '[{\"date\": \"1/28/2023\", \"title\": \"Saturday\", \"requester\": \"Nada Wafa\"}, {\"date\": \"1/26/2023\", \"title\": \"Public\", \"requester\": \"Nada Wafa\"}, {\"date\": \"1/8/2023\", \"title\": \"Public\", \"requester\": \"Nada Wafa\"}, {\"date\": \"1/5/2023\", \"title\": \"PTO\", \"requester\": \"Nada Wafa\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `saturday_req`
--

CREATE TABLE `saturday_req` (
  `ID` int(11) NOT NULL,
  `date` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pool_a_level_1` int(1) DEFAULT NULL,
  `pool_a_level_2` int(1) DEFAULT NULL,
  `pool_b_level_1` int(1) DEFAULT NULL,
  `pool_b_level_2` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `saturday_req`
--

INSERT INTO `saturday_req` (`ID`, `date`, `pool_a_level_1`, `pool_a_level_2`, `pool_b_level_1`, `pool_b_level_2`) VALUES
(2, '1/7/2023', 0, 1, 0, 1),
(4, '1/14/2023', 0, 0, 0, 1),
(5, '1/21/2023', 0, 0, 0, 0),
(9, '1/28/2023', 1, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE `userlogin` (
  `id` int(11) NOT NULL,
  `nt_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `isMod` tinyint(1) NOT NULL,
  `pool` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(1) NOT NULL,
  `skill` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `shift` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `isSaturday` text COLLATE utf8_unicode_ci NOT NULL,
  `isAvaya` text COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`id`, `nt_name`, `password`, `isMod`, `pool`, `level`, `skill`, `shift`, `isSaturday`, `isAvaya`, `notes`) VALUES
(1, 'admin_u', 'mm156', 0, '1', 0, 'file_system', NULL, '0', '', ''),
(2, 'admin_m', 'mm145', 1, '0', 0, 'admin', NULL, '0', '', ''),
(3, 'Abdelrahman Hesham', '23128', 0, '0', 0, 'SMB', 'Sun-Thurs', 'Yes', 'Yes', ''),
(4, 'Abdelrahman Khaled', '36771', 0, '1', 0, 'FileSystem,Hardware', 'Sun-Thurs', 'Yes', 'Yes', ''),
(5, 'Sebai', '76495', 0, '0', 1, 'NFS', 'Sun-Thurs', 'Mgmt', 'No', ''),
(6, 'Ahmed Mostafa', '30968', 0, '0', 0, 'NFS', 'Mon-Fri', 'No', 'Yes', ''),
(7, 'Ahmed Seif', '45331', 0, '1', 0, 'FileSystem,BackUp,Hardware', 'Sun-Thurs', 'No', 'Yes', ''),
(8, 'Ahmed Wael', '19285', 0, '1', 0, 'FileSystem,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(9, 'Alaa Saad', '90346', 0, '1', 0, 'Admin,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(10, 'Ali Rashwan', '40238', 0, '1', 1, 'Admin,Hardware', 'Sun-Thurs', 'Yes', 'No', ''),
(11, 'Ali Tawakol', '87856', 0, '1', 0, 'FileSystem,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(12, 'Amany Ayman', '13104214', 0, '0', 0, 'Networks', 'Sun-Thurs', 'Yes', 'Yes', ''),
(13, 'Andrew Danial', '39967', 0, '1', 0, 'Admin,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(14, 'Aya Radwan', '90120', 0, '1', 1, 'Admin', 'Sun-Thurs', 'Mgmt', 'No', ''),
(15, 'Dawlat Elgendy', '39181', 0, '0', 1, 'NFS', 'Sun-Thurs', 'Yes', 'No', ''),
(16, 'Faisal Essam', '79196', 0, '1', 0, 'FileSystem,Hardware', 'Sun-Thurs', 'Yes', 'Yes', ''),
(17, 'Farida Al-Bohaisy', '81042', 0, '1', 0, 'FileSystem,BackUp,Hardware', 'Sun-Thurs', 'Yes', 'Yes', 'Maternity'),
(18, 'Fatma Shalaby', '82344', 0, '1', 0, 'FileSystem,Hardware', 'Sun-Thurs', 'Yes', 'Yes', ''),
(19, 'Heba Hegazi', '89015', 0, '1', 0, 'FileSystem,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(20, 'Jailan Raafat', '61186', 0, '1', 1, 'Coach,FileSystem', 'Sun-Thurs', 'No', 'No', ''),
(21, 'Kareem Ramadan', '44135', 0, '1', 0, 'Admin,Hardware', 'Sun-Thurs', 'Yes', 'No', ''),
(22, 'Karim Hawas', '73804', 0, '1', 0, '', '', 'No', 'No', 'New Hire'),
(23, 'Mahmoud Khater', '65771', 0, '0', 0, 'SMB', 'Sun-Thurs', 'Yes', 'Yes', ''),
(24, 'Mahmoud Osama', '57794', 0, '0', 0, 'Networks', 'Sun-Thurs', 'Yes', 'Yes', ''),
(25, 'Marwa Mashaly', '25001', 0, '0', 0, 'Networks', 'Mon-Fri', 'No', 'Yes', ''),
(26, 'Mazen Elbehiry', '83544', 0, '1', 0, '', 'Sun-Thurs', 'No', 'Yes', 'New Hire'),
(27, 'Menna Yassin', '73024', 0, '1', 0, 'FileSystem,Hardware', 'Sun-Thurs', 'Yes', 'Yes', ''),
(28, 'Mennatallah Sayed', '41883', 0, '1', 0, 'Admin,Hardware', 'Sun-Thurs', 'Yes', 'Yes', ''),
(29, 'Michael Masry', '402001040', 0, '1', 0, 'BackUp,FileSystem,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(30, 'Mirette Hossam Eldin', '74072', 0, '0', 0, 'SMB', '', '', 'Yes', 'Onboarding'),
(31, 'Mohamed Abdelfattah', '36641', 0, '0', 0, 'Networks', 'Mon-Fri', 'No', 'Yes', ''),
(32, 'Mohamed Elleithy', '86936', 0, '0', 0, 'SMB', 'Sun-Thurs', 'Yes', 'Yes', ''),
(33, 'Mohamed Krima', '97121', 0, '1', 0, 'BackUp,NDMP,Hardware', 'Sun-Thurs', 'Yes', 'Yes', 'Sautrday as a 3rd pool B option, not one of the main 2'),
(34, 'MohamedLoaui Zamzam', '53139', 0, '0', 1, 'SMB', 'Sun-Thurs', 'No', 'No', ''),
(35, 'Mohamed Saeed', '85492', 0, '1', 0, 'FileSystem,BackUp,Hardware', 'Mon-Fri', 'Yes', 'Yes', ''),
(36, 'Mohamed Seleem', '72561', 0, '1', 0, 'FileSystem,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(37, 'Mohammed Badawi', '76004', 0, '1', 1, 'Admin', 'Sun-Thurs', 'Mgmt', 'No', ''),
(38, 'Mostafa Elbahrawy', '98692', 0, '1', 0, 'FileSystem,BackUp,Hardware', 'Sun-Thurs', 'Yes', 'Yes', ''),
(39, 'Nada Wafa', '70009', 0, '1', 0, 'FileSystem,BackUp,Hardware', 'Sun-Thurs', 'Yes', 'Yes', ''),
(40, 'Naglaa Ahmed', '63839', 0, '1', 1, 'FS Pod Lead', 'Sun-Thurs', 'Yes', 'No', ''),
(41, 'Nourhan Said', '27556', 0, '1', 0, 'BackUp,FileSystem,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(42, 'Nourhan Soliman', '46916', 0, '1', 0, 'Admin,Hardware', 'Sun-Thurs', 'Yes', 'Yes', ''),
(43, 'Omar Mahdy', '24316', 0, '1', 0, 'FileSystem,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(44, 'Radwa Khairy', '38321', 0, '0', 0, 'SMB', 'Mon-Fri', 'No', 'Yes', ''),
(45, 'Rana Suliman', '27644', 0, '1', 0, '', '', 'No', 'No', 'New Hire'),
(46, 'Rawan Shehab', '24732', 0, '1', 1, 'Admin', 'Mon-Fri', 'No', 'No', ''),
(47, 'Reem Gendy', '89127', 0, '1', 1, 'FileSystem', 'Sun-Thurs', 'Yes', 'Yes', ''),
(48, 'Reem Hesham', '61964', 0, '1', 0, 'FileSystem,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(49, 'Rehan Khattab', '42611', 0, '0', 1, 'Networks', 'Sun-Thurs', 'Yes', 'No', ''),
(50, 'Salma El-Zalabany', '47732', 0, '1', 1, 'TAM', 'Mon-Fri', 'No', 'No', ''),
(51, 'Samer Elhosainy', '67494', 0, '1', 0, 'FileSystem,BackUp,Hardware', 'Mon-Fri', 'No', 'Yes', ''),
(52, 'Sohayla Fath Elbab', '67175', 0, '0', 0, 'NFS', 'Sun-Thurs', 'Yes', 'Yes', ''),
(53, 'Yousef Shaltout', '23372', 0, '0', 0, 'NFS', 'Sun-Thurs', 'Yes', 'Yes', ''),
(54, 'Youssef Mahdy', '54077', 0, '0', 0, 'NFS', 'Mon-Fri', 'No', 'Yes', ''),
(55, 'Zeinab El Sayed', '19312', 0, '0', 1, 'NFS', 'Sun-Thurs', 'Yes', 'No', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `month`
--
ALTER TABLE `month`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pto_record`
--
ALTER TABLE `pto_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saturday_req`
--
ALTER TABLE `saturday_req`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userlogin`
--
ALTER TABLE `userlogin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `month`
--
ALTER TABLE `month`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `pto_record`
--
ALTER TABLE `pto_record`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=290;

--
-- AUTO_INCREMENT for table `saturday_req`
--
ALTER TABLE `saturday_req`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
