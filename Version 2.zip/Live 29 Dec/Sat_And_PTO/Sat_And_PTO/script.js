let nav = 1;
var x;
userDashboardDisplayed=false
var listPTO = [];
var listPublic = [];
var pushedPTO = false;
var pushedPublic = false;
var current_user = localStorage.getItem("current_user").split(",");
//console.log("current user: " + current_user);
var currentUserPool = current_user[2];
//console.log("current pool: " + currentUserPool);
var currentUserLevel = current_user[3];
//console.log("current level: " + currentUserLevel);
owner_ID = current_user[0];
//console.log(owner_ID);
if (currentUserPool == 0 && currentUserLevel == 0) {
  currentUserTitle = "Pool A - L1";
} else if (currentUserPool == 0 && currentUserLevel == 1) {
  currentUserTitle = "Pool A - L2";
} else if (currentUserPool == 1 && currentUserLevel == 0) {
  currentUserTitle = "Pool B - L1";
} else if (currentUserPool == 1 && currentUserLevel == 1) {
  currentUserTitle = "Pool B - L2";
}
//console.log(localStorage.getItem("user"));
saturdayCount = 0;
saturdayDates = [];
saturdaysFetched = [];
let clicked = null;
let events = localStorage.getItem("events")
  ? JSON.parse(localStorage.getItem("events"))
  : [];
options = ["Avaya", "Saturdays", "PTO", "Public", "Other"];
const calendar = document.getElementById("calendar");
const newEventModal = document.getElementById("newEventModal");
const deleteEventModal = document.getElementById("deleteEventModal");
const backDrop = document.getElementById("modalBackDrop");
const eventTitleInput = document.getElementById("eventTitleInput");
const weekdays = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
var owner_ = localStorage.getItem("user");
// var mysql = require('mysql');
//console.log(owner_);
//console.log(events);
flag = false;
flagPTO = false;
flagPublic = false;
satFlag = true;
//Saturdays:
//this should be customized later or keep as default
saturdayRequestedDepartments = [
  "pool A - L1",
  "pool B - L1",
  "pool A - L2",
  "pool B - L2",
  "pool B - L1",
];
//this should be fetched on login from database

var poolalevel1 = 0;
var poolalevel2 = 0;
var poolblevel2 = 0;
var poolblevel2 = 0;
var satindex;
var a1 = 0;
var a2 = 0;
var b1 = 0;
var b2 = 0;
currentUserPoolLevel = "" + currentUserPool + "" + currentUserLevel;
var satData = [];
var globalDateString = "";

function openModal(date) {
  clicked = date;
  dateStr = clicked;
  globalDateString = dateStr;
  //handleSaturdays();
  var datestring = clicked.split("/");
  var dd = datestring[0];
  var mm = datestring[1];
  var yyyy = datestring[2];
  datestring = mm + "/" + dd + "/" + yyyy;
  invertedDate = dd + "/" + mm + "/" + yyyy;
  var dateObject = new Date(datestring);
  var invertedDateObject = new Date(invertedDate);
  var selectobject = document.getElementById("eventTitleInput");
  var checker;
  //console.log(listPTO);
  //console.log(listPublic);
  a = JSON.stringify(listPTO);
  b = JSON.stringify(listPublic);
  //console.log("$$$$$$$$$$$$$$$" + a.indexOf(invertedDate) + "$$$$$$$$$$$$$$$");

  if (a.indexOf(invertedDate) == -1 && flagPublic == false) {
    //console.log(true);
    const opt = document.createElement("option");
    opt.value = "Public";
    opt.text = "Public";
    selectobject.add(opt, null);
    flagPublic = true;
    getPublicReq();
  } else {
    for (i = 0; i < listPublic.length; i++) {
      //console.log("CHECKER: " + listPublic[i][1]);
      //console.log("DATE: " + listPublic[i][0]);
      //console.log("LENGTH: " + listPublic.length);
      if (listPublic[i][0] == invertedDate && listPublic[i][1] <= 0) {
        for (j = 0; j < selectobject.length; j++) {
          //console.log("public WALA LA2" + selectobject.options[j].value);
          if (selectobject.options[j].value == "Public") {
            //console.log("oki doki");
            //console.log(false);
            selectobject.remove(j);
            flagPublic = false;
            //console.log;
            getPublicReq();
          }
        }
      } else if (listPublic[i][0] == invertedDate && listPublic[i][1] > 0) {
        if (flagPublic == false) {
          //console.log(true);
          const opt = document.createElement("option");
          opt.value = "Public";
          opt.text = "Public";
          selectobject.add(opt, null);
          flagPublic = true;
          getPublicReq();
        }
      } else if (
        listPublic[i][0] == invertedDate &&
        i == listPublic.length - 1 &&
        flagPublic == false
      ) {
        //console.log(true);
        const opt = document.createElement("option");
        opt.value = "Public";
        opt.text = "Public";
        selectobject.add(opt, null);
        flagPublic = true;
        getPublicReq();
      }
    }
  }
  if (a.indexOf(invertedDate) == -1 && flagPTO == false) {
    //console.log(true);
    const opt = document.createElement("option");
    opt.value = "PTO";
    opt.text = "PTO";
    selectobject.add(opt, null);
    flagPTO = true;
    getPTOReq();
  } else {
    for (i = 0; i < listPTO.length; i++) {
      //console.log("CHECKER: " + listPTO[i][1]);
      //console.log("DATE: " + listPTO[i][0]);
      //console.log("LENGTH: " + listPTO.length);
      if (listPTO[i][0] == invertedDate && listPTO[i][1] <= 0) {
        for (j = 0; j < selectobject.length; j++) {
          //console.log("PTO WALA LA2" + selectobject.options[j].value);
          if (selectobject.options[j].value == "PTO") {
            //console.log("oki doki");
            //console.log(false);
            selectobject.remove(j);
            flagPTO = false;
            //console.log;
            getPTOReq();
          }
        }
      } else if (listPTO[i][0] == invertedDate && listPTO[i][1] > 0) {
        if (flagPTO == false) {
          //console.log(true);
          const opt = document.createElement("option");
          opt.value = "PTO";
          opt.text = "PTO";
          selectobject.add(opt, null);
          flagPTO = true;
          getPTOReq();
        }
      } else if (
        listPTO[i][0] == invertedDate &&
        i == listPTO.length - 1 &&
        flagPTO == false
      ) {
        //console.log(true);
        const opt = document.createElement("option");
        opt.value = "PTO";
        opt.text = "PTO";
        selectobject.add(opt, null);
        flagPTO = true;
        getPTOReq();
      }
    }
  }
  //console.log("********************");
  //console.log(currentUserTitle);
  ////console.log(poolalevel1)
  //console.log("********************");
  if (currentUserTitle == "Pool A - L1") {
    checker = poolalevel1;
  } else if (currentUserTitle == "Pool A - L2") {
    checker = poolalevel2;
  } else if (currentUserTitle == "Pool B - L1") {
    checker = poolblevel1;
  } else if (currentUserTitle == "Pool B - L2") {
    checker = poolblevel2;
  }

  //console.log("Checker: " + checker);
  //console.log(invertedDateObject);
  for (var i = 0; i < selectobject.length; i++) {
    if (invertedDateObject.getDay() === 6 && flag == false && checker > 0) {
      //console.log(true);
      const opt = document.createElement("option");
      opt.value = "Saturday";
      opt.text = "Saturday";
      selectobject.add(opt, null);
      flag = true;
    } else if (
      invertedDateObject.getDay() != 6 &&
      flag == true &&
      selectobject.options[i].value == "Saturday"
    ) {
      //console.log(false);
      selectobject.remove(i);
      flag = false;
    } else if (
      invertedDateObject.getDay() === 6 &&
      flag == true &&
      checker <= 0 &&
      selectobject.options[i].value == "Saturday"
    ) {
      //console.log(false);
      selectobject.remove(i);
      flag = false;
    }
  }
  //   for (var i=0; i<selectobject.length; i++) {

  //   if ((selectobject.options[i].value == 'Saturday' && dateObject.getDay() != 6 && flag==true ) || (selectobject.options[i].value == 'Saturday' && dateObject.getDay() == 6 && flag==true && a1<=0)){
  //     //console.log("gpwa"+a1)
  //     selectobject.remove(i);
  //     flag=false;

  //   }else if (flag==false){
  //     //console.log("vara " +a1)
  //     const opt = document.createElement("option");
  //     opt.value = "Saturday";
  //     opt.text = "Saturday";
  //     selectobject.add(opt, null);
  //     flag=true;
  //   }
  //   if (selectobject.options[i].value == 'Saturday' && dateObject.getDay() == 6 ){
  //     var option = document.createElement("option");
  //     option.text = "Saturday";
  //     selectobject.add(option);
  //   }
  // }
  //handleSaturdays();

  const eventForDay = events.find((e) => e.date === clicked);

  if (eventForDay) {
    document.getElementById("eventText").innerText = eventForDay.title;
    document.getElementById("eventTitleInput").innerText = [
      "test",
      "the",
      "change",
    ];
    deleteEventModal.style.display = "block";
  } else {
    newEventModal.style.display = "block";
  }

  backDrop.style.display = "block";
}

function load() {
  const dt = new Date();

  if (nav !== 0) {
    dt.setMonth(new Date().getMonth() + nav);
  }

  const day = dt.getDate();
  const month = dt.getMonth();
  const year = dt.getFullYear();

  const firstDayOfMonth = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const dateString = firstDayOfMonth.toLocaleDateString("en-us", {
    weekday: "long",
    year: "numeric",
    month: "numeric",
    day: "numeric",
  });
  const paddingDays = weekdays.indexOf(dateString.split(", ")[0]);

  document.getElementById("monthDisplay").innerText = `${dt.toLocaleDateString(
    "en-us",
    { month: "long" }
  )} ${year}`;

  calendar.innerHTML = "";

  for (let i = 1; i <= paddingDays + daysInMonth; i++) {
    const daySquare = document.createElement("div");
    daySquare.classList.add("day");

    const dayString = `${month + 1}/${i - paddingDays}/${year}`;
    ////console.log(dayString);
    today = new Date(dayString);
    if (today.getDay() == 6 && saturdayCount < 5) {
      saturdayCount++;
      saturdayDates.push(dayString);
    }
    if (i > paddingDays) {
      daySquare.innerText = i - paddingDays;
      const eventForDay = events.find((e) => e.date === dayString);

      if (i - paddingDays === day && nav === 0) {
        daySquare.id = "currentDay";
      }

      if (eventForDay) {
        const eventDiv = document.createElement("div");
        eventDiv.classList.add("event");
        eventDiv.innerText = eventForDay.title;
        daySquare.appendChild(eventDiv);
      }

      daySquare.addEventListener("click", () => getSaturdayReq(dayString));
    } else {
      daySquare.classList.add("padding");
    }

    calendar.appendChild(daySquare);
  }
  for (i = 0; i < events.length; i++) //console.log(events[i]);
  //again////console.log(saturdayCount);
  ////console.log(saturdayDates);
  getPTOForDashboard();
}

function closeModal() {
  eventTitleInput.classList.remove("error");
  newEventModal.style.display = "none";
  deleteEventModal.style.display = "none";
  backDrop.style.display = "none";
  eventTitleInput.value = "";
  clicked = null;
  //handleSaturdays();

  load();
}

function saveEvent() {
  //if user chose Saturday checker
  var dateStr = clicked;
  var dateObject = new Date(dateStr);

  if (
    eventTitleInput.value == "Saturday" &&
    dateObject.getDay() === 6 &&
    saturdayRequestedDepartments.filter((x) => x == "").length !=
      saturdayRequestedDepartments.length
  ) {
    // if(currentUserPoolLevel)
    //console.log("ekhtart Saturday");
    if (saturdayRequestedDepartments.includes(currentUserTitle)) {
      //console.log("exists");
      //console.log(saturdaysFetched);
      //saturdayRequestedDepartments[saturdayRequestedDepartments.indexOf(currentUserTitle)]='';
      ////console.log(saturdayRequestedDepartments);

      executeEvent();
    } else {
      //alert('This Saturday is taken, please choose another day')
      executeEvent();
    }
  }

  //if user chose PTO checker
  if (eventTitleInput.value == "PTO") {
    //console.log("ekhtart PTO");
    executeEvent();
    closeModal();
  }
  //if user chose Avaya checker
  if (eventTitleInput.value == "Avaya") {
    //console.log("ekhtart Avaya");
    executeEvent();
    closeModal();
  }
  //if user chose Public checker
  if (eventTitleInput.value == "Public") {
    //console.log("ekhtart Public");
    executeEvent();
    closeModal();
  }
  //if user chose Other checker
  if (eventTitleInput.value == "Other") {
    //console.log("ekhtart Other");
    executeEvent();
    closeModal();
  } else closeModal();
}
function executeEvent() {
  if (eventTitleInput.value) {
    eventTitleInput.classList.remove("error");
    //console.log(owner_);
    for (i = 0; i < eventTitleInput.length; i++) {
      if (options[i] == eventTitleInput.value) {
        options[i] = "";
      }
    }
    //console.log(options);
    events.push({
      date: clicked,
      title: eventTitleInput.value,
      requester: owner_,
    });

    localStorage.setItem("events", JSON.stringify(events));
    closeModal();
  } else {
    eventTitleInput.classList.add("error");
  }
}

function send_to_server() {
  if(!events||events===null|| events===[] || events.length<1){
    alert("Please choose an event first")
  }
  else{
  (async () => {
    try {
      //console.log("dakhalt el async");
      const rawResponse = await fetch("http://localhost:8080/savelist", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ ownerID: owner_ID, name: owner_, pto: events }),
      });
      const status_ = await rawResponse.json();
      //console.log(status_["status"]);

      if (status_["status"] == "OK") {
        //console.log("Script FINE");
      } else {
        //console.log("Script NOT OK");
      }
      //console.log("hakhrog men el async");
      getPTOForDashboard();
    } catch (error) {
      alert("Please logout and login again");
    }

    getPTOReq();
    getPublicReq();
    //Send data to server. remove user, events
    localStorage.removeItem("user");
    localStorage.removeItem("events");
    //load();
    //console.log(localStorage.getItem("user"));
    //console.log(localStorage.getItem("events"));
    events = [];
    load();
    //console.log("sending to server");
    open_thanks();
    update_saturday();
  })();

  /*//console.log("Clicked~!!!!!");
	var xhr = new XMLHttpRequest();
	xhr.open("POST", 'http://localhost:8080/savelist', true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	var obj = {"ownerID":1, "name":owner_, "pto":events};
	//console.log(obj);
	xhr.send(JSON.stringify({
		"value": obj
	}));*/
}}
function open_thanks() {
  window.open("./thanks.html", "_self");
}
function deleteEvent() {
  events = events.filter((e) => e.date !== clicked);
  localStorage.setItem("events", JSON.stringify(events));
  closeModal();
}

function initButtons() {
  //error because we open another window and still call this so there is no button
  //in the new window with that ID

  // document.getElementById('backButton').addEventListener('click', () => {
  //  // nav--;
  //   load();
  // });
  document.getElementById("saveButton").addEventListener("click", saveEvent);
  document.getElementById("cancelButton").addEventListener("click", closeModal);
  document
    .getElementById("deleteButton")
    .addEventListener("click", deleteEvent);
  document.getElementById("closeButton").addEventListener("click", closeModal);
  document
    .getElementById("submitButton")
    .addEventListener("click", send_to_server);
  document.getElementById("logoutButton").addEventListener("click", logout);
  //document.getElementById('homepage').addEventListener('click', redirecttohomepage);
  // document.getElementById("Removebtn").addEventListener("click", removeEvent);
}
function logout() {
  window.open("./index.html", "_self");
}

function getSaturdayReq(dayString) {
  saturdaysFetched = [];
  (async () => {
    const rawResponse = await fetch(
      "http://localhost:8080/getSaturdayRequirements",
      {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      }
    );
    const sat = await rawResponse.json();
    var requirement;
    for (i = 0; i < sat.length; i++) {
      //console.log("Sat [i][1]: " + sat[i][1]);
      //console.log("dayString: " + dayString);
      if (sat[i][1] == dayString) {
        requirement = sat[i];
        break;
      } else {
        requirement = 0;
      }
    }
    // requirement = sat[0];
    //console.log(requirement);
    poolalevel1 = requirement[2];
    poolalevel2 = requirement[3];
    poolblevel1 = requirement[4];
    poolblevel2 = requirement[5];
    satData = sat;
    getPTOReq();
    getPublicReq();
    openModal(dayString);
  })();
  //console.log("khalast fetching saturday");
}
function getPTOReq(dayString) {
  saturdaysFetched = [];
  (async () => {
    const rawResponse = await fetch("http://localhost:8080/getPTOReq", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    });
    const sat = await rawResponse.json();
    // requirement = sat[0];
    ////console.log(sat)
    if (pushedPTO == false) {
      for (i = 0; i < sat.length; i++) {
        listPTO.push([sat[i][0], sat[i][1]]);
      }
      pushedPTO = true;
    } else {
      listPTO = [];
      for (i = 0; i < sat.length; i++) {
        listPTO.push([sat[i][0], sat[i][1]]);
      }
    }
  })();

  //console.log("khalast fetching saturday");
}
function getPublicReq(dayString) {
  saturdaysFetched = [];
  (async () => {
    const rawResponse = await fetch("http://localhost:8080/getPTOReq", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    });
    const sat = await rawResponse.json();
    // requirement = sat[0];
    //console.log(sat);
    if (pushedPublic == false) {
      for (i = 0; i < sat.length; i++) {
        listPublic.push([sat[i][0], sat[i][2]]);
      }
      pushedPublic = true;
    } else {
      listPublic = [];
      for (i = 0; i < sat.length; i++) {
        listPublic.push([sat[i][0], sat[i][2]]);
      }
    }
  })();

  //console.log("khalast fetching saturday");
}

// function handleSaturdays(){
//   var datestring = globalDateString.split("/");
//   var mm = datestring[0];
//   var dd = datestring[1];
//   var yyyy = datestring[2];
//   var newDateFormat = dd+"/"+mm+"/"+yyyy
//   //console.log(newDateFormat)

//   var exist = false;

//   for(i=0;i<satData.length;i++){
//     if(satData[i][1]==newDateFormat){
//       exist=true
//       satindex=i;
//       a1=satData[i][2];
//       a2=satData[i][3];
//       b1=satData[i][4];
//       b2=satData[i][5];
//     }
//   }
//   //console.log(satFlag)
//   //if chosen one is saturday, check the pool and the level, if equal
//   //to my pool and level then continue and reduce the availability
// }

// function update_saturday(){

// 	(async () => {
//     //console.log("dakhalt el update_saturday");
// 		const rawResponse = await fetch('http://localhost:8080/savesat', {
// 			method: 'POST',
// 			headers: {
// 				'Accept': 'application/json',
// 				'Content-Type': 'application/json'
// 			},
// 			body: JSON.stringify({ "pool_a_level_1":a1, "pool_a_level_2":a2, "pool_b_level_1":b1, "pool_b_level_2":b2,"date":globalDateString})
// 		});
// 		const status_ = await rawResponse.json();
// 		//console.log(status_['status']);

// 		if (status_['status'] == "OK") {
// 			//console.log("Script FINE");
// 		}else{
// 			//console.log("Script NOT OK");
// 		}
// 		//console.log("hakhrog men el async");
// 	})();
// }

function getPTOForDashboard() {
  if(userDashboardDisplayed==false){
  (async () => {
    //IP localhost thaanks
    const rawResponse2 = await fetch(
      "http://localhost:8080/data_per_user",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ ownerID: owner_ID }),
      }
    );
    const status_ = await rawResponse2.json();
    viewData(status_["records"]);

    //console.log("da el response: " + status_);
  })();
  userDashboardDisplayed=true
}
}
function viewData(data) {
  ptolist__ = [];
  //console.log("de el data el gya" + data);
  for (i = 0; i < data.length; i++) {
    // console.log(typeof data[i]);
    current_object_id = JSON.parse(data[i][0]);
    current_object_record = JSON.parse(data[i][1]);
    for (j = 0; j < current_object_record.length; j++) {
      //console.log("parsed: " + JSON.parse(data[i][0])[0]["date"]);
      ptolist__.push({
        id: current_object_id,
        date: current_object_record[j]["date"],
        type: current_object_record[j]["title"],
      });
    }
    //console.log("de pto list gowa el for loop: "+ptolist__)
  }
  // console.log("De el pto list: " + ptolist__);
  displayDashboard(ptolist__);
}

// function displayDashboard(data) {
//   tablebody = document.getElementById("userdashboard");
//   for (i = 0; i < data.length; i++) {
//     var row = tablebody.insertRow(0);
//     var cell1 = row.insertCell(0);
//     cell1.innerHTML = data[i]["type"];
//     var cell2 = row.insertCell(1);
//     cell2.innerHTML = data[i]["date"];
//     var cell3 = row.insertCell(2);
//     cell3.innerHTML = '<button class="Removebtn">Button</button>'; 
//   }
// }

function removeEvent(){
      alert("are you sure you want to delete this event?")
}


// TRIAL
function displayDashboard(data) {
  let table_body = document.getElementById('table_body')
      for (i = 0; i < data.length; i++) {
        console.log(data[i])
        var row = table_body.insertRow(0);
        row.style.textAlign = "center";
        var cell4 = row.insertCell(0);
        cell4.style.textAlign = "center";
        cell4.innerHTML = data[i]["id"];
        var cell2 = row.insertCell(1);
        cell2.innerHTML = data[i]["date"];
        cell2.style.textAlign = "center";
        var cell1 = row.insertCell(2);
        cell1.innerHTML = data[i]["type"];
        cell1.style.textAlign = "center";
        var cell3 = row.insertCell(3);
        cell3.innerHTML = ' <div class="action_container" style="align: center, border: 1px solid"><button class="danger style="display: block; margin: 0 auto;"" onclick="remove_tr(this)"><i class="fa fa-close"></i> Delete</button></div>';}
        cell3.style.textAlign = "center";

}

function remove_tr(This) {
  if(This.closest('tbody').childElementCount == 1)
  {
      alert("You Don't have Permission to Delete This ?");
  }else{
    eventString = This.closest('tr').textContent.split('  ')[0]
    //console.log(eventString);
    //console.log(eventString.split(/[0-9]/));
    //console.log(new Date(eventString));

      if(confirm("Are you sure you want to delete this entry?")){
        // console.log(This.closest('tr'))
        // This.closest('tr').remove();'
        var currentRow= $(This).closest('tr'); // get current row 2nd TD
        var id=currentRow.find("td:eq(0)").text(); // get current row 3rd TD
        alert(id);
        (async () => {
          //IP localhost thaanks
          const rawResponse2 = await fetch(
            "http://localhost:8080/deleterecord",
            {
              method: "POST",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ id: id }),
            }
          );
          location.reload()
        })();
        
      }
  }
}

getPTOForDashboard();
getPTOReq();
getPublicReq();
load();
initButtons();
// function redirecttohomepage(){
//   window.open("./record.html","_self");
// }
